# token_optimizer

Universal Token & Prompt Cache Optimizer for Claude Code, Antigravity, Cursor, and Codex.

## What it does
- Dynamic Context Relocation (Static Prefix + Tail Relocation)
- Multi-Model Routing Ladder (Flash / Sonnet / Opus)
- Deterministic Tool Schema Alphabetization
- Thread Cache Preservation (No Model Switch Thrashing)

## Quick Install

### Claude Code
Copy skills/token_optimizer to ~/.claude/skills/token_optimizer

### Antigravity / Gemini
Copy skills/token_optimizer to ~/.gemini/skills/token_optimizer

### Cursor
Copy skills/token_optimizer to .cursor/skills/token_optimizer

### Codex / Standard Agents
Copy skills/token_optimizer to ~/.agents/skills/token_optimizer

